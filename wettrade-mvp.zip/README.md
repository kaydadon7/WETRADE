# WETRADE MVP
## איך להפעיל את הפרויקט
1. התקן את התלויות: `npm install`
2. הרץ את השרת המקומי: `npm run dev`
3. היכנס ל- `http://localhost:3000` ובדוק את הפלטפורמה!
