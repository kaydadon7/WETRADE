import { CommunityPage } from '../components/CommunityPage';
export default function Community() {
  return <CommunityPage />;
}