import { LoginPage } from '../components/LoginPage';
export default function Home() {
  return <LoginPage />;
}